using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class influencerScript : characterScript
{
    public influencerScript(string name, int xp, int health, Sprite sprite) : base(name, xp, health, sprite){}

	new public void setSymptoms(List<Util.Effects> efeitos){

    }
    /*new public void setEffects(List<Util.Symptoms> simtomas){

    }*/
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
